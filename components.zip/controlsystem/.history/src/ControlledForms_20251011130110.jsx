import React from 'react'

function ControlledForms() {
    const [name]
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
