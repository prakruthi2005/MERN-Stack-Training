import React from 'react'

function SimpleValidation() {
    const
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
