import React from 'react'

function ControlledForms() {
    const [name, setName]=uses
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
