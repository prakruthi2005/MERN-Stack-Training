import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input ty
      </form>
    </div>
  )
}

export default HtmlForms
