import React, { use, useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const[error,setError]=useState('');
    const handlesubmit=(e)=>{
        e.preventDefault();
        if(!email.include)
    }
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
