import React from 'react'
import './App.css'
import HtmlForms from './HtmlForms'
import ControlledForms from './ControlledForms'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './SimpleValidation'

function App() {
  return (
    <>
      <HtmlForms />
      <ControlledForms />
      <TwoWayBinding />
      <
    </>
  )
}
export default App
