import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input t
      </form>
    </div>
  )
}

export default HtmlForms
