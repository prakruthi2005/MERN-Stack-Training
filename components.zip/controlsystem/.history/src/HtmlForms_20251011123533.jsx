import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input type='email' id='user'/>
        <input type='password' id='pass'/>
        <button>Submit</button>
      </form>
    </div>
  )
}

export default HtmlForms
