import React, { use, useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const[error,setError]=useState('');
    const handlesubmit=(e)=>{
        e.prevent
    }
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
