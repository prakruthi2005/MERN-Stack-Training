import React from 'react'

function ControlledForms() {
    const [name, setName]
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
