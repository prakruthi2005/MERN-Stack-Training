import React, { useState } from 'react'

function TwoWayBinding() {
    const[message,setMessage]=useState('')
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
