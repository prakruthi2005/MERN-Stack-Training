import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input type='email' id='user'/>
        <input type='password' id=''
      </form>
    </div>
  )
}

export default HtmlForms
