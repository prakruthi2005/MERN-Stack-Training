import React from 'react'

function TwoWayBinding() {
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
