import React, { useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const[error,setError]=useState('');
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes('@')){
            setError('please enter a valid email');
        }else{
            setError('');
            alert(`Email Submitted:${email}`);
        }
    };
  return (
    <from onSubmit={handleSubmit}>
        <input type='email' value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <button type='submit'>Submit</button>
        
    </from>
  )
}

export default SimpleValidation
