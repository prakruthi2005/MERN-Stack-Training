import React from 'react'

function TwoWayBinding() {
    const[me]
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
