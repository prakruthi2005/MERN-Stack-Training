import React, { useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const [error,setError]=useState('');
    const [phno,setPhno]=useState('');
    const [error1,setError1]=useState('');
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes('@')){
            setError('please enter a valid email');
        }else{
            setError('');
            alert(`Email Submitted:${email}`);
        }
        if(phno.length===10){}
            setError1('please enter a valid number');
        }else{
            setError1('');
            alert(`Phone number is submitted:${phno}`);
        }
    };
  return (
    <form onSubmit={handleSubmit}>
        <input type='email' value={email} onChange={(e)=>setEmail(e.target.value)}/><br></br>
        <input type='number' value={phno} onChange={(e)=>setPhno(e.target.value)}/><br></br>
        <button type='submit'>Submit</button>
        {error && <p style={{color:'red'}}>{error}</p>}
        {error1 && <p style={{color:'red'}}>{error1}</p>}
    </form>
  );
  
}
console.log(Number.length);


export default SimpleValidation;
