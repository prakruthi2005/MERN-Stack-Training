import React from 'react'

function TwoWayBinding() {
    const[message,setMesssage]
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
