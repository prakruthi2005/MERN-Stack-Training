import React, { useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const [phno,setPhno]=useState('');
    const[error,setError]=useState('');
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes('@')){
            setError('please enter a valid email');
        }else{
            setError('');
            alert(`Email Submitted:${email}`);
        }
    };
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(Phno)
    }
  return (
    <form onSubmit={handleSubmit}>
        <input type='email' value={email} onChange={(e)=>setEmail(e.target.value)}/><br></br>
        <input type='number' value={phno} onChange={(e)=>setPhno(e.target.value)}/><br></br>
        <button type='submit'>Submit</button>
        {error && <p style={{color:'red'}}>{error}</p>}
    </form>
  );
}

export default SimpleValidation;
