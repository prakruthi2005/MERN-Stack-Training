import React from 'react'

function ControlledForms() {
    const [name, setName]=use
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
