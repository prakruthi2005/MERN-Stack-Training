import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input
      </form>
    </div>
  )
}

export default HtmlForms
