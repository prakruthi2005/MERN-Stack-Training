import React, { useState } from 'react'

function TwoWayBinding() {
    const[message,setMessage]=useState('Hello');
  return (
    <div>
      <input type='text'
    </div>
  )
}

export default TwoWayBinding
