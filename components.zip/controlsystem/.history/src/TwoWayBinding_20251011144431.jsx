import React from 'react'

function TwoWayBinding() {
    const[message,setMessage]=user
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
