import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input type=''
      </form>
    </div>
  )
}

export default HtmlForms
