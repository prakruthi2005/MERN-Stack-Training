import React, { useState } from 'react'

function ControlledForms() {
    const [name, setName]=useState('')
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
