import React, { useState } from 'react'

function ControlledForms() {
    const [name, setName]=useState('');  //1st executes     //5th executed
    const handleChange=(e)=>{//4th executes
        setName(e.target.value);
        document.getElementById('result').innerText=e.target.value;
    };
    const handleSubmit=(e)=>{//7th executes
        e.preventDefault();
        alert( `Submitted Name :${name}`);
    };
  return (
    <div>
      <form onSubmit={handleSubmit}>     //2nd executes
        <label>Enter your name:</label>
        <input type='text' value={name} onChange={handleChange}/> //3rd executes
        <button type='submit'>Submit</button>//6th executes
      </form>
      <p id='result'></p>
    </div>
  );
}

export default ControlledForms;
