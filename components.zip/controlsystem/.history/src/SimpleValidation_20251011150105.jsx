import React, { use, useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const[error,setError]=useState('');
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes('@')){
            setError('please enter a valid email');
        }else{
            setError('');
            alert(`Email Submitted:${email}`)

        }
    }
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
