// ...existing code...
import React from 'react'
import './App.css'
import HtmlForms from './HtmlForms'
import ControlledForms from './ControlledForms'
import TwoWayBinding from './TwoWayBinding'

function App() {
  return (
    <>
      <HtmlForms />
      <ControlledForms />
      <TwoWayBinding />
    </>
  )
}
export default App
