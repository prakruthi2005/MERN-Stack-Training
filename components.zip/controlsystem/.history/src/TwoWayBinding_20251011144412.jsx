import React from 'react'

function TwoWayBinding() {
    const
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
