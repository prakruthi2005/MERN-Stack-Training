import React from 'react'

function SimpleValidation() {
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
