import React, { useState } from 'react'

function TwoWayBinding() {
    const[message,setMessage]=useState('Hello');
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
