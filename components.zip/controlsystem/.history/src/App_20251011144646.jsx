import React  from 'react'
//import reactLogo from './assets/react.svg'
//import viteLogo from '/vite.svg'
import './App.css'
import HtmlForms from './HtmlForms'
import ControlledForms from './ControlledForms'
import TwoWayBinding from './TwoWayBinding'

function App() {
  return(
    //<HtmlForms id='user'/>
    <ControlledForms id='result'/>

  )
}
export default App
