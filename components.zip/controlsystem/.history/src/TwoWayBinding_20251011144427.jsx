import React from 'react'

function TwoWayBinding() {
    const[message,setMessage]
  return (
    <div>
      
    </div>
  )
}

export default TwoWayBinding
