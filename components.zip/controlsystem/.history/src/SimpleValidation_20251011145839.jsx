import React, { useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('')
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
