import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        
      </form>
    </div>
  )
}

export default HtmlForms
