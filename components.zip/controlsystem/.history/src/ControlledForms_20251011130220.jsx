import React, { useState } from 'react'

function ControlledForms() {
    const [name, setName]=useState('');
    const handleChange=(e)=>{
        setName(e.target)
    }
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
