import React from 'react'

function SimpleValidation() {
    const [email,setEmail]
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
