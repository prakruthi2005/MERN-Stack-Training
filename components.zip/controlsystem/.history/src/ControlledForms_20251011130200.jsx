import React, { useState } from 'react'

function ControlledForms() {
    const [name, setName]=useState('');
    const handleChange
  return (
    <div>
      
    </div>
  )
}

export default ControlledForms
