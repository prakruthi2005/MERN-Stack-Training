import React, { useState } from 'react'

function SimpleValidation() {
    const [email,setEmail]=useState('');
    const[error,setError]
  return (
    <div>
      
    </div>
  )
}

export default SimpleValidation
