import React, { useState } from 'react'

function ControlledForms() {
    const [name, setName]=useState('');
    const handleChange=(e)=>{
        setName(e.target.value);
        document.getElementById('result').innerText=e.target.value;
    };
    const handleSubmit=(e)=>{
        e.preventDefault();
        alert(Submitted Name :${name});
    };
  return (
    <div>
      <form onSubmit={handleSubmit}>
        
      </form>
    </div>
  )
}

export default ControlledForms
