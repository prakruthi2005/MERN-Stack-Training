import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <firstcomponent/>
  )
}
export default App
