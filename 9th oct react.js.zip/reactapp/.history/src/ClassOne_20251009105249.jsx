import React from 'react';
class Fruit extends React.Component{
    return (){
        return <h1> A class Component</h1>
    }
}

export default 