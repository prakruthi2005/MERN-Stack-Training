import React from 'react'

function fcomponent(prakruthi) {
  return (
    <div>
      <h1>fcomponent</h1>
    </div>
  )
}

export default fcomponent
