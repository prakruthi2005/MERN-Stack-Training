import React from 'react'


function firstcomponent() {
  return (
    <div>
      First Component{}
    </div>
  )
}

export default firstcomponent
