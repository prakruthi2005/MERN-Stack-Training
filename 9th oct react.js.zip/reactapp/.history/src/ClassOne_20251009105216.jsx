import React from 'react';
class Fruit extends React.Component{
    return 
}