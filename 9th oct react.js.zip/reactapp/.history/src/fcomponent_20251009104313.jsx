import React from 'react'

function fcomponent(prakruthi) {
  return (
    <div>
      fcomponent
    </div>
  )
}

export default fcomponent
