import React from 'react'


function firstcomponent() {
  return (
    <div>
      First ComponentPrakruthi.name
    </div>
  )
}

export default firstcomponent
