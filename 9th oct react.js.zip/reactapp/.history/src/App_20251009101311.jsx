import React from 'react'
import irstcomponent from './firstcomponent'
function App() {
  return (
    <firstcomponent/>
  )
}
export default App
