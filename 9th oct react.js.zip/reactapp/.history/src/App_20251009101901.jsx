import React from 'react'
import  from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
export default App
