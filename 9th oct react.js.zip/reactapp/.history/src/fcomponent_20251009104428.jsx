import React from 'react'

function fcomponent(prakruthi) {
  return (
    <div>
      <h1>fComponent{prakruthi.name}</h1>
    </div>
  )
}

export default fcomponent
