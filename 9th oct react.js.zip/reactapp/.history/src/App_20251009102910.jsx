import React from 'reac
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
