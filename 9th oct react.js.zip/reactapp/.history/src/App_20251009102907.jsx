import React from 'react'
import FirstComponent
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
