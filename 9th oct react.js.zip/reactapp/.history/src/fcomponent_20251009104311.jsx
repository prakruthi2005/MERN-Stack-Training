import React from 'react'

function fcomponent(prakruthi) {
  return (
    <div>
      fcomp
    </div>
  )
}

export default fcomponent
