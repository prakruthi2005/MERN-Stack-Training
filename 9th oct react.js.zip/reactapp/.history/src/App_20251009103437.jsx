import React from 'react';

function FirstComponent(prakruthi) {
  return (
    <div>
      <h1>FirstComponent {prakruthi.name}</h1>
      <SecondComponent phno: />
    </div>
  );
}

function SecondComponent(prakruthi1) {
  return (
    <div>SecondComponent {prakruthi1.name}</div>
  );
}

export default FirstComponent;
