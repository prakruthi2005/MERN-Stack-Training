import React from 'react'


function firstcomponent(Prakruthi) {
  return (
    <div>
     <h1> FirstComponent{Prakruthi.name}</h1>
     <SecondComponent
    </div>
  )
}
function SecondComponent(abc){
  return(
    <div>SecondComponent{abc.name}</div>
  )
}
export default firstcomponent
