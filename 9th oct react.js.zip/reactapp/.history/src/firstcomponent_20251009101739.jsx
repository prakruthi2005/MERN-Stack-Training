import React from 'react'


function firstcomponent() {
  return (
    <div>
      First Component>Prakruthi.name</Component>
    </div>
  )
}

export default firstcomponent
