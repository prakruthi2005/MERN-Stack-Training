import React from 'react'

function App() {
  return (
    <FirstComponent/>
  )
}

export default App
