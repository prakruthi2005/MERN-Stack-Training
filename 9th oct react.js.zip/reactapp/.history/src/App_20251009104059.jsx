import React from 'react';
import FirstComponent from './firstomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
    </div>
  );
}

export default App;
