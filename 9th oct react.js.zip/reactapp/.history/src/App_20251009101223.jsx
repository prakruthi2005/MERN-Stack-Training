import React from 'react'
import Fire
function App() {
  return (
    <firstcomponent/>
  )
}

export default App
