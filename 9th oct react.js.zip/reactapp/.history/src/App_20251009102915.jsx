import React from 'react'
import 
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
