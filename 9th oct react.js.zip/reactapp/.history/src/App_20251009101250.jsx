import React from 'react'
import firstcomponent from './firstcomponent'
function App() {
  return (
    <firstcomponent/>
  )
}
export default App
