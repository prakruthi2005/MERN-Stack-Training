import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
function SecondComponent(abc){
  return(
    <div>SecondComponent{</div>
  )
}
export default App
