import React from 'react'
import firstcomponent from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
export default App
