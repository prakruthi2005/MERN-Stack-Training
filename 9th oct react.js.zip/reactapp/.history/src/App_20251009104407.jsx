import React from 'react';
import FirstComponent from './firstcomponent';
import fcomponent from './fcomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
    </div>
  );
}

export default App;
