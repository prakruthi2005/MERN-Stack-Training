import React from 'react';

function FirstComponent(Prakruthi) {
  return (
    <div>
      <h1>FirstComponent{Prakruthi.name}</h1>
      <SecondComponent phno='6362713824'/>
    </div>
  )
}
function SecondComponent(Prakruthi){
    return(
        <div>SecondComponent:{Prakruthi.phno}</div>
    )
}

export default FirstComponent
