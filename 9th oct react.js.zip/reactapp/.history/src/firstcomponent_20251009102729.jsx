import React from 'react'

function FirstComponent(Prakruthi) {
  return (
    <div>
      <h1>FirstComponent{</h1>
    </div>
  )
}

export default FirstComponent
