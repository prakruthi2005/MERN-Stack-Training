import React from 'react'

function FirstComponent(Prakruthi) {
  return (
    <div>
      <h1>FirstCom</h1>
    </div>
  )
}

export default FirstComponent
