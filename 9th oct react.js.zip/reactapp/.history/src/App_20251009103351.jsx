import React from 'react';

function FirstComponent(prakruthi) {
  return (
    <div>
      <h1>FirstComponent {.name}</h1>
      <SecondComponent name={props.name} />
    </div>
  );
}

function SecondComponent(props) {
  return (
    <div>SecondComponent {props.name}</div>
  );
}

export default FirstComponent;
