import React from 'react'


function firstcomponent() {
  return (
    <div>
      First Component{Prakruth}
    </div>
  )
}

export default firstcomponent
