import React from 'react';
import FirstComponent from './firstcomponent';
import fomponent from './fcomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
    </div>
  );
}

export default App;
