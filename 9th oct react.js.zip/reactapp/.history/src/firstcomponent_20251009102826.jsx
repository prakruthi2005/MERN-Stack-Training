import React from 'react'

function FirstComponent(Prakruthi) {
  return (
    <div>
      <h1>FirstComponent{Prakruthi.name}</h1>
      <SecondComponent/>
    </div>
  )
}
function SecondComponent(Prakruthi){
    return(
        <div>Secon</div>
    )
}

export default FirstComponent
