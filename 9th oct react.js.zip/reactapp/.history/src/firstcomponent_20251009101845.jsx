import React from 'react'


function firstcomponent(Prakruthi) {
  return (
    <div>
      FirstComponent{Prakruthi.name}
    </div>
  )
}

export default firstcomponent
