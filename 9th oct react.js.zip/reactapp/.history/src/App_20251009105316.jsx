import React from 'react';
import FirstComponent from './firstcomponent';
Fruit 

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
    </div>
  );
}

export default App;
