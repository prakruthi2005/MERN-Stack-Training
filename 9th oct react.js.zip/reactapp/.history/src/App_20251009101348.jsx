import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <Frstcomponent/>
  )
}
export default App
