import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <irstcomponent/>
  )
}
export default App
