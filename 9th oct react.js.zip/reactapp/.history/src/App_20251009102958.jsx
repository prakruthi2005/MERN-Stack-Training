import React from 'react'
import FirstComponent from './irstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
