import React from 'react'


function firstcomponent() {
  return (
    <div>
      First ComponentPrakruthi.name</Component>
    </div>
  )
}

export default firstcomponent
