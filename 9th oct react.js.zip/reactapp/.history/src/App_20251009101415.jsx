import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <Firstomponent/>
  )
}
export default App
