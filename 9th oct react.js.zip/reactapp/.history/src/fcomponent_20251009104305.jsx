import React from 'react'

function fcomponent(prakruthi) {
  return (
    <div>
      
    </div>
  )
}

export default fcomponent
