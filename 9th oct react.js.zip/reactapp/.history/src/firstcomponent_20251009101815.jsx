import React from 'react'


function firstcomponent(Prakruthi) {
  return (
    <div>
      First Component{Prakruthi.name}
    </div>
  )
}

export default firstcomponent
