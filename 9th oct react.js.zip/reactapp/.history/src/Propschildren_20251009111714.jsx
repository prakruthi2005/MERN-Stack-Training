import React from 'react';



function Son(props) {
  return (
    <div style={{background: 'lightgreen'}}>
      <h2>Son</h2>
      <div>{props.children}</div>
    </div>
  );
}

function Daughter({brand,model,children}) {
  return (
    <div style={{background: 'lightblue'}}>
      <h2>Daughter{brand </h2>
      <div>{children}</div>
    </div>
  );
}

function Parent() {
  return (
    <div>

