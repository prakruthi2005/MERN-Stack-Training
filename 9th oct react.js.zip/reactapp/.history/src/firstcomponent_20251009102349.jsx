import React from 'react'


function firstcomponent(Prakruthi) {
  return (
    <div>
      FirstComponent{Prakruthi.name}
    </div>
  )
}
function SecondComponent(abc){
  return(
    <div>SecondComponent{abc.name}</div>
  )
}
export default firstcomponent
