import React from 'react'
import Firstcomponent from './firstcomponent'
function App() {
  return (
    <firstcomponent/>
  )
}
export default App
