import React from 'react';
class Fruit extends React.Component{
    return (){
        return <h1> A c</h1>
    }
}