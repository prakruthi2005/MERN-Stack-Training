import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
function SecondComponent(abc){
  return(
    <div>SecondComponent{abc.name}</div>
  )
}
export default App
