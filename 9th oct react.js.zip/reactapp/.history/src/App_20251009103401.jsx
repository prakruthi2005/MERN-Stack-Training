import React from 'react';

function FirstComponent(prakruthi) {
  return (
    <div>
      <h1>FirstComponent {prakruthi.name}</h1>
      <SecondComponent name={props.name} />
    </div>
  );
}

function SecondComponent(prakruthi) {
  return (
    <div>SecondComponent {props.name}</div>
  );
}

export default FirstComponent;
