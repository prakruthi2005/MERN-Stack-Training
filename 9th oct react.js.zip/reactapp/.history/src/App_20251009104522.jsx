import React from 'react';
import FirstComponent from './firstcomponent';
import fcomponent from './fcomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      <fcomponent name='prakruthi'/>
    </div>
  );
}

export default App;
