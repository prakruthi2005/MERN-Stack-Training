import React from 'react';
import FirstComponent from './firstcomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      
    </div>
  );
}

export default App;
