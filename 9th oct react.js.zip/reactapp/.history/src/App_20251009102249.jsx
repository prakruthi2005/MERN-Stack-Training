import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
function SecondComponent(abc){
  return(
    
  )
}
export default App
