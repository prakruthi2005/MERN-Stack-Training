import React from 'react';
import FirstComponent from './firstcomponent';
import Fruit from './ClassOne';


function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
      <Fruit/>
      <
    </div>
  );
}

export default App;
