import React from 'react'
import Fir from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}
export default App
