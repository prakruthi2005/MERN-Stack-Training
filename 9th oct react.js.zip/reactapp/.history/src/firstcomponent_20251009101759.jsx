import React from 'react'


function firstcomponent() {
  return (
    <div>
      First Component{Prakruthi.name
    </div>
  )
}

export default firstcomponent
