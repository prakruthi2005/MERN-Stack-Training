import React from 'react';
import FirstComponent from './firstcomponent';
import Fruit from './ClassOne';
import Parent from './Propschildren';


function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
      <FirstComponent name="Prakruthi" />
      
      <Parent/>
    </div>
  );
}

export default App;
