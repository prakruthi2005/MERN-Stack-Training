import React from 'react'
import Firstcomp
function App() {
  return (
    <firstcomponent/>
  )
}

export default App
