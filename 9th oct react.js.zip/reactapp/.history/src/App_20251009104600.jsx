import React from 'react';
import FirstComponent from './firstcomponent';

function App() {
  return (
    <div>
      <FirstComponent name="Prakruthi" />
      <fcomponent name='prakruthi'/>
    </div>
  );
}

export default App;
