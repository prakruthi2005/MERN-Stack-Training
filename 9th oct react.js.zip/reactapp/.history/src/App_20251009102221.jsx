import React from 'react'
import FirstComponent from './firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
