import React from 'react'
import FirstComponent from './Firstcomponent'
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
