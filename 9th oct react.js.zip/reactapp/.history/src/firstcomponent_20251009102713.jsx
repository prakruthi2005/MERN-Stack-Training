import React from 'react'

function FirstComponent(Prakruthi) {
  return (
    <div>
      
    </div>
  )
}

export default FirstComponent
