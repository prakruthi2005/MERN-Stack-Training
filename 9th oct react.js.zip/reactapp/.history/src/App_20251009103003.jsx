import React from 'react'
import FirstComponent from './FirstComponent'
function App() {
  return (
    <FirstComponent/>
  )
}

export default App
